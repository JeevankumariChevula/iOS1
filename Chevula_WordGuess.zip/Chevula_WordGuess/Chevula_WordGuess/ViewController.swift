//
//  ViewController.swift
//  Chevula_WordGuess
//
//  Created by Chevula,Jeevan Kumari on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var guessletterbuttonoutlet: UIButton!
    
    @IBOutlet weak var playagainbuttonoutlet: UIButton!
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var arraywords = [["DOG","bow bow"],
                      ["COW","gives milk"],
                      ["RAT","Jerry"],
                      ["CAT","Tom"],
                      ["FISH","Swims"]]
    var guess = ""
    var imagesview = ["Dog","Cow","Rat","Cat","Fish"]
    var l = ""
    var wordIterator = 0
    var guessedletcount = ""
    let maxNumOfWrongGuesses  = 10
    var guessleft = 10
    var count = 0
    var guessedwords = 0
    var wronginputs = 0
    var tryvariable=0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        l = arraywords[wordIterator][0]
                guess = arraywords[wordIterator][1]
                hintLabel.text = "HINT: " + guess;
                wordsGuessedLabel.text = "Total number of words Guessed  succesfully:0"
                totalWordsLabel.text = "Total number of words in the game: \(arraywords.count)"
                wordsRemainingLabel.text = "Total number of words remaining in the game: \(arraywords.count)"
                guessCountLabel.text = "You have Made 0 guesses"
        guessLabelOPT()
                guessletterbuttonoutlet.isEnabled = false
                playagainbuttonoutlet.isHidden = true
    }
    
    func updateOPTS(){
            wordsGuessedLabel.text = "Total number of words Guessed  succesfully: \(guessedwords)"
            wordsRemainingLabel.text = "Total number of words remaining in the game:\(arraywords.count - (guessedwords + wronginputs))"
        }
    
    func guessLabelOPT() {
            var ouput = ""
            guessedletcount += guessLetterField.text!
            
            for l in l {
                if guessedletcount.contains(l) {
                    ouput = ouput + " \(l)"
                } else {
                    ouput += " _"
                }
            }
            ouput.removeFirst()
            userGuessLabel.text = ouput
        }
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        displayImage.isHidden = true
                wordIterator += 1
                if wordIterator == arraywords.count {
                    wordIterator = 0
                    guessedwords = 0
                    wronginputs = 0
                    updateOPTS()
                }
                l = arraywords[wordIterator][0]
                guess = arraywords[wordIterator][1]
                hintLabel.text = "HINT: " + guess
                
        playagainbuttonoutlet.isHidden = true
                guessLetterField.isEnabled = true
        guessletterbuttonoutlet.isEnabled = false
                
                guessleft = maxNumOfWrongGuesses
                guessedletcount = ""
        guessLabelOPT()
                guessCountLabel.text = "You have Made 0 Guesses"
                count = 0
        }
    
    
    @IBAction func guessletterfieldchanges(_ sender: UITextField) {
        if let letterGuessed = guessLetterField.text?.last {
                    guessLetterField.text = "\(letterGuessed)"
            guessletterbuttonoutlet.isEnabled = true
                } else {
                    
                    guessletterbuttonoutlet.isEnabled = false
                }
        
    }
    
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        guesslettersmethod()
        guessmethods()
                let l = guessLetterField.text
                if l?.isEmpty == true{
                    guessletterbuttonoutlet.isEnabled = false
                    statusLabel.isHidden = true
                }
                else{
                    guessletterbuttonoutlet.isEnabled = true
                    statusLabel.isHidden = true
                }
        
    }
    func guessmethods(){
            
            guessLetterField.resignFirstResponder()
            
            guessLetterField.text = ""
        }
        func guesslettersmethod() {
            guessLabelOPT()
            count += 1
            
            
            let letterguessed = guessLetterField.text!
            
            if !l.contains(letterguessed) {
                
                guessleft = guessleft - 1
                
            }
            
            let outputword = userGuessLabel.text!
            
            if guessleft == 0 {
                
                playagainbuttonoutlet.isHidden = false
                guessLetterField.isEnabled = false
                guessletterbuttonoutlet.isEnabled = false
               // tryvariable+=1
                guessCountLabel.text = "You have used all the available guesses, Please play again"
                wronginputs += 1
                updateOPTS()
                updateImageView()
                displayImage.isHidden = true
            } else if !outputword.contains("_") {
                playagainbuttonoutlet.isHidden = false
                guessLetterField.isEnabled = false
                guessletterbuttonoutlet.isEnabled = false
                guessCountLabel.text = "Wow, You have made \(count) guesses to guess the word!"
                guessedwords += 1
                updateOPTS()
                updateImageView()
            } else {
                // Update our guess count
                //let guess = ( count == 1 ? "Guess" : "Guesses")
                guessCountLabel.text = "You have Made \(count) guesses"
            }
            if (guessedwords + wronginputs) == arraywords.count {
                statusLabel.text = "Congratulations, You are done, Please start over again "
                updateImageView()
            }
        }
    
    
    func updateImageView(){
            var count=0
            if(guessleft==0){
                 count = wordIterator
                wordIterator=5
            }
            displayImage.isHidden = false
            displayImage.image = UIImage(named: imagesview[wordIterator])
            let originalImageFrame = displayImage.frame
            let widthShrink: CGFloat = 10
            let heightShrink: CGFloat = 10
            let newFrame = CGRect(
            x: displayImage.frame.origin.x + widthShrink,
            y: displayImage.frame.origin.y + heightShrink,
            width: displayImage.frame.width - widthShrink,
            height: displayImage.frame.height - heightShrink)
            displayImage.frame = newFrame
            UIView.animate(withDuration: 1.0, delay: 0, usingSpringWithDamping: 0.2, initialSpringVelocity: 10.0,  animations: {
                self.displayImage.frame = originalImageFrame
            })
            if(guessleft==0){
                wordIterator = count
            }
        }
    

    }


