//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Chevula,Jeevan Kumari on 3/23/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgaeViewOL: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //min X and min Y
        
        let minX = imgaeViewOL.frame.minX
        let minY = imgaeViewOL.frame.minY
        print("(\(minX),\(minY))")
        
        
        let maxX = imgaeViewOL.frame.maxX
        let maxY = imgaeViewOL.frame.maxY
        print("(\(maxX),\(maxY))")
        
        let midX = imgaeViewOL.frame.midX
        let midY = imgaeViewOL.frame.midY
        print("(\(midX),\(midY))")
        
        // move the location of an image to upper right corner.
        imgaeViewOL.frame.origin.x = 286
        imgaeViewOL.frame.origin.y = 0
        
        // move the location of an image to bottom left corner.
        imgaeViewOL.frame.origin.x = 0
        imgaeViewOL.frame.origin.y = 825
        
        // move the location of an image to bottom right corner.
        imgaeViewOL.frame.origin.x = 314
        imgaeViewOL.frame.origin.y = 796
        
        // move the location of an image mid point of the screen.
        imgaeViewOL.frame.origin.x = 157
        imgaeViewOL.frame.origin.y = 398
}
}
