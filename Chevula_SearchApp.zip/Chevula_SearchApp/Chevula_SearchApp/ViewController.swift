//
//  ViewController.swift
//  Chevula_SearchApp
//
//  Created by Chevula,Jeevan Kumari on 3/23/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBOutlet weak var SearchButtonActionOL: UIButton!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    @IBOutlet weak var Prevbtn: UIButton!
    
    
    @IBOutlet weak var Nextbtn: UIButton!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    var arrList = [["Season1","Season2","Season3","Season4","Season5"], ["Trekkingspot1","Trekkingspot2","Trekkingspot3","Trekkingspot4", "Trekkingspot5"],["Businessperson1","Businessperson2", "Businessperson3","Businessperson4","Businessperson5"]]
    
    var Seasons_Keywords = ["Climate","Wheather","Rainy","Winter","Summer","Autum","Spring"]
    var Trekkingspots_Keywords = ["Hikking","Mountainclimbing","Trekking","Cycling","Bikeride"]
    var Businesspersons_Keywords = ["Businessman","Businesswoman","Businessperson","entrepreneur","Industrialist"]
    
    var arr_topics = ["Climate change refers to long-term shifts in temperatures and weather patterns. These shifts may be natural, such as through variations in the solar cycle.","Wheather is reffered as the state of the atmosphere in regard to heat or cold, wetness or dryness, calm or storm, clearness or cloudiness. Disagreeable atmospheric conditions. stormy weather.","Relief comes with the monsoon. Temperatures are around 35 °C (95 °F) but humidity is very high; nights are around 27 °C (81 °F). Most of the rainfall occurs in this season, and the rain can cause severe floods. The sun is often occluded during the monsoon season.","All of Missouri experiences freezing temperatures every year. In winter there is an average of about 110 days with temperature below 32° F in the northern","Summer is the warmest of Earth's four temperate seasons and occurs between spring and fall.","spring, in climatology, season of the year between winter and summer during which temperatures gradually rise.","Meteorological","fall (aka autumn) is defined as the months of September, October and November in the Northern Hemisphere (it's spring in the Southern Hemisphere).","Hiking is an activity of moderate difficulty, which involves walking across long distances generally on trails or paths. The duration of the activity varies between short half-day programs and longer itineraries of over 20 days. It is usually an activity that allows groups of different sizes.","Mountaineering, or mountain climbing, is the sport of reaching, or trying to reach, high points in mountainous areas, mainly for the joy and thrill of the climb. The sport involves intense physical activity.","Trekking is an outdoor activity of walking for more than a day. It is a form of walking, undertaken with the specific purpose of exploring and enjoying the scenery.","cycling, use of a bicycle for sport, recreation, or transportation. The sport of cycling consists of professional and amateur races, which are held mostly in continental Europe, the United States, and Asia.","Set in the 1960s, it follows the rise of a fictional Midwestern motorcycle club. Seen through the lives of its members, the club evolves over the course of a decade from a gathering place for local outsiders into a more sinister gang, threatening the original group's unique way of life.","A highly ambitious man comes to Mumbai with the idea of ruling the city; he turns into a local gangster and goes on to become a powerful businessman, whose intentions are not what they seem.","The Businesswoman enters the subway station talking on her cell. READ MORE - PRO MEMBERS ONLY. Join the StageAgent community to read our character","A businessperson undertakes activities (commercial or industrial) for the purpose of generating cash flow, sales, and revenue by using a combination of human, financial, intellectual, and physical capital with a view to fueling economic development and growth.","An entrepreneur is someone who has an idea and who works to create a product or service that people will buy, as well as an organization to support that effort.","In biohydrogen production system, researchers, industrialists, policymakers, and local biomass suppliers are the four major stakeholders."]
    
    var imagetopic:Int = 0
    var imageValue:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Nextbtn.isEnabled = false
        Prevbtn.isEnabled = false
        SearchButtonActionOL.isEnabled = false
        resultImage.image = UIImage(named: "Results_Notfound")
        
    }


    @IBAction func searchbtnEn(_ sender: Any) {
        
        let text = searchTextField.text!
        if(text.isEmpty){
            SearchButtonActionOL.isEnabled = false
        }else{
            SearchButtonActionOL.isEnabled = true
        }
    }
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        let textValue = searchTextField.text!
        
        if(Seasons_Keywords.contains(textValue)){
            imagetopic = 0
            imageValue = 0
            Details(imagetopic,imageValue)
            
        }else if(Trekkingspots_Keywords.contains(textValue)){
            imagetopic = 1
            imageValue = 0
            Details(imagetopic,imageValue)
           
        }else if(Businesspersons_Keywords.contains(textValue)){
            imagetopic = 2
            imageValue = 0
            Details(imagetopic,imageValue)
            
        }else{
            resultImage.image = UIImage(named: "Incorrect_Input")
            topicInfoText.text = ""
            Nextbtn.isEnabled = false
        }
        Nextbtn.isEnabled = true

    }
    
    
    @IBAction func ShowPrevButton(_ sender: UIButton) {
        imageValue = imageValue - 1
                Nextbtn.isEnabled = true
                if(imageValue == 0){
                    Prevbtn.isEnabled = false
                }
                Details(imagetopic,imageValue)

}
    
    
    @IBAction func resetButton(_ sender: UIButton) {
        SearchButtonActionOL.isHidden = true
                searchTextField.isHidden = true
                Nextbtn.isHidden = true
                Prevbtn.isHidden = true
                topicInfoText.isHidden = true
                imagetopic = 0
                imageValue = 0
    }
    
    
    
    @IBAction func ShowNextButton(_ sender: UIButton) {
        imageValue = imageValue  + 1
        Prevbtn.isEnabled = true
        if(imageValue == 4){
            Nextbtn.isEnabled = false
        }
        Details(imagetopic,imageValue)
    }
    
    func Details(_ topiccount: Int,_ imagecount:Int)
    
    {
    
        resultImage.image = UIImage(named: arrList[topiccount][imagecount])
        topicInfoText.text = arr_topics[topiccount]
    }
    

}

